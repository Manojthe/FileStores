// info.js
module.exports = {
    botToken: '7930127889:AAGq8RQ1jmOuFIOi7COmFx6DekTNcXumcpQ',
    channelId: '-1002292366057',
    mongoURI: 'mongodb+srv://amantuber:gmwRsHK3tnKFD06x@telegrambot.scb67.mongodb.net/Telegrambot?retryWrites=true&w=majority',
    botUsername: 'PricetrackerBot',
    FNQD: 'https://90bdf5c4-cfbd-4d1d-9eeb-d37daa98812d-00-2t2uf908cgyog.pike.replit.dev',

        // Set the image URL and caption with HTML formatting
    imageUrl: 'https://i.ibb.co/M537YnP/image.jpg', // Replace with your image URL
    caption: `<b>Welcome to the bot!</b>\nChoose an option below:`, // HTML formatted caption
adminId: 875770605 // Add the admin ID here

  
};

    